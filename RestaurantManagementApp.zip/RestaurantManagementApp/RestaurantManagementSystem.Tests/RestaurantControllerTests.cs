﻿using NUnit.Framework;
using RestaurantManagementSystem.Controllers;
using RestaurantManagementSystem.Models;
using System.Web.Mvc;
using System.Linq;
using System.Collections.Generic;
using System;
using System.Collections.Specialized;
using System.Globalization;

namespace RestaurantManagementSystem.Tests
{
    [TestFixture]
    class RestaurantControllerTests
    {
        [Test]
        public void TestIndexAction_ReturnRestaurantList()
        {
            //Arrange
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();

            //Act
            var viewResult = restaurantController.Index() as ViewResult;
            var restaurants = (IEnumerable<Restaurant>)viewResult.ViewData.Model;

            //Assert
            try
            {
                Assert.AreEqual(db.Restaurants.ToList().Count, restaurants.ToList().Count);
            }
            catch(Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }
        [Test]
        public void TestAddRestaurantAction_CuisineDefaultValue()
        {
            //Arrange
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            Restaurant restaurant = new Restaurant();
            restaurant.Name = "Dominos";
            //Cuisine default value "None"
            restaurant.LaunchDate = DateTime.Today;
            restaurant.OnlineOrders = true;


            //Act
            var result = (RedirectToRouteResult)restaurantController.AddRestaurant(restaurant);


            try
            {
                //Assert
                Assert.AreEqual(result.RouteValues["action"], "Details");
            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding new restaurant to the database failed.Cuisine default value should be provided. Please check the application logic");
            }


        }
        [Test]
        public void TestAddRestaurantAction_SavesToDatabase_ValidModel()
        {
            //Arrange
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            Restaurant restaurant = new Restaurant();
            restaurant.Name = "Rasavid";
            restaurant.Cuisine = CuisineType.Indian;
            restaurant.LaunchDate = DateTime.Today;
            restaurant.OnlineOrders = true;

            //Act
            var result = (RedirectToRouteResult)restaurantController.AddRestaurant(restaurant);

            
            try
            {
                //Assert
                Assert.AreEqual(result.RouteValues["action"].Equals("Details"), true);
            }
            catch(Exception)
            {
                Assert.Fail("Adding new restaurant to the database failed.Exception should not be thrown. Please provide all mandatory fields valid data.");
            }
            

        }
        [Test]
        public void TestAddRestaurantAction_NameNull()
        {
            //Arrange
            var restaurantController = new RestaurantController();

            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            Restaurant restaurant = new Restaurant
            {
                Cuisine = CuisineType.Indian,
                LaunchDate = DateTime.Today,
                OnlineOrders = true
            };

            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => restaurant, restaurant.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);
            restaurantController.ModelState.Clear();
            restaurantController.ModelState.Merge(modelBinder.ModelState);

            try
            {
                //Act
                var viewRresult = restaurantController.AddRestaurant(restaurant) as ViewResult;
                //Assert
                Assert.AreNotEqual(viewRresult.ViewName,"Details");


            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding restaurant to the database failed. Name can't be empty, please provide valid data for Name");
            }



        }

        [Test]
        public void TestAddRestaurantAction_LaunchDateNull()
        {
            //Arrange
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            Restaurant restaurant = new Restaurant();
            restaurant.Name = "abc restaurant";
            restaurant.Cuisine = CuisineType.Indian;
            //don't provide value for LaunchDate field
            restaurant.OnlineOrders = true;

            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => restaurant, restaurant.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);
            restaurantController.ModelState.Clear();
            restaurantController.ModelState.Merge(modelBinder.ModelState);

            try
            {
                //Act
                var viewResult = restaurantController.AddRestaurant(restaurant) as ViewResult;
                //Assert
                Assert.AreNotEqual(viewResult.ViewName,"Details");
            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding restaurant to the database failed. Launch date should not be blank, please provide valid data.");
            }

        }

        [Test]
        public void TestAddRestaurantAction_IdAutoGenerated()
        {
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            Restaurant restaurant = new Restaurant();
            restaurant.Name = "kfc";
            restaurant.Cuisine = CuisineType.Italian;
            restaurant.LaunchDate = DateTime.Today;
            restaurant.OnlineOrders = true;

            //Act
            try
            {
                int maxIdBefore = db.Restaurants.Max(r => r.Id);
                var result = (RedirectToRouteResult)restaurantController.AddRestaurant(restaurant);
                int maxIdAfter = db.Restaurants.Max(r => r.Id);
                

            //Assert
            
                Assert.AreEqual(maxIdBefore+1,maxIdAfter);
            }
            catch (Exception)
            {
                Assert.Fail("Adding new restaurant to the database failed.Id should be auto generated. Please check the database scheme, ensure identity function specified on Id column");
            }

        }
        [Test]
        public void TestDetailsAction_ForValidId()
        {
            //Arrange
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            int validId = db.Restaurants.Max(r => r.Id);//getting valid max id
            //Act

            var viewResult = restaurantController.Details(validId) as ViewResult;
            var restaurant = (Restaurant)viewResult.ViewData.Model;

            //Assert
            try
            {
                Assert.NotNull(restaurant);
            }
            catch (Exception)
            {
                Assert.Fail("No such restaurant, please provide a valid restaurant id.");
            }
        }
        [Test]
        public void TestDetailsAction_ForInvalidId()
        {
            //Arrange
            var restaurantController = new RestaurantController();
            RestaurantManagementDbContext db = new RestaurantManagementDbContext();
            int validId = db.Restaurants.Max(r => r.Id);//getting valid max id
            int invalidId=validId += 5000;//adding 5000 to valid id to make it invalid to test

            //Act
            var viewResult = restaurantController.Details(invalidId) as ViewResult;
            var restaurant = (Restaurant)viewResult.ViewData.Model;

            //Assert
            try
            {
                Assert.Null(restaurant);
            }
            catch (Exception)
            {
                Assert.Fail("Invalid id, please provide a valid restaurant id");
            }
        }
        [Test]
        public void TestAddRestaurantAction_InitalizesDbContext()
        {
            //Arrange
            var restaurantController = new RestaurantController();


            //Act
            var viewResult = restaurantController.AddRestaurant(
                new Restaurant
                { Name = "Pizza Hut",
                  Cuisine = CuisineType.American,
                  LaunchDate = DateTime.Today,
                  OnlineOrders = true,
                }) as ViewResult;


            
            try
            {
                
                //Assert

                Assert.NotNull(RestaurantController.db);
            }
            catch (Exception)
            {
                Assert.Fail("Database creation failed, please check the connection string");
            }
        }

       

    }
    }

