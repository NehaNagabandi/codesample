﻿using System;
//using System.Collections.Generic;
//using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

namespace RestaurantManagementSystem.Models
{
    public class Restaurant
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="Please Provide Restaurant Name")]  
        [MaxLength(255)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please Select Cuisine Type")]
        [Display(Name="Type of food")]
        public CuisineType Cuisine { get; set; }

        [Required(ErrorMessage = "Please Provide Onliner Order")]
        [Display(Name = "Open for Online Orders?")]
        public bool OnlineOrders { get; set; }

        [Required(ErrorMessage = "Please Provide Valid Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = true)]
        public DateTime? LaunchDate { get; set; }

         
    }
}
