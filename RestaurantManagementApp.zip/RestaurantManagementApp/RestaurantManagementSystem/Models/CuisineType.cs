﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantManagementSystem.Models
{
    public enum CuisineType
    {
        None,
        Italian,
        Indian,
        French,
        Mexican,
        Chineese,
        Japaneese,
        Iranian,
        Spanish,
        Greece,
        American,
        Arabian
       

    }
}
