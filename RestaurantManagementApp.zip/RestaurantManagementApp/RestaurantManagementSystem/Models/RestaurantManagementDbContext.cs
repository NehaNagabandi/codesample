﻿using RestaurantManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantManagementSystem.Models
{
    public class RestaurantManagementDbContext : DbContext
    {
        public DbSet<Restaurant> Restaurants { get; set; }
        public RestaurantManagementDbContext():base("RMS_DB")
        {

        }
    }
}
