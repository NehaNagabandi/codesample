﻿using System;
using System.Linq;
using System.Web.Mvc;
using RestaurantManagementSystem.CustomFilters;
using RestaurantManagementSystem.Models;
namespace RestaurantManagementSystem.Controllers
{
    [CustomExceptionFilter]
    public class RestaurantController : Controller
    {
        //Kindly have custom exception filter at the controller level. 
        //On exception, kindly use console.log to write exception message
        //in browser console 

        public static RestaurantManagementDbContext db;
        [HttpGet]
        public ActionResult Index()
        {
            
                db = new RestaurantManagementDbContext();
                ViewBag.Message = "This is Index Action";
                var model = db.Restaurants;
                return View(model);
            
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            db = new RestaurantManagementDbContext();
                var model = db.Restaurants.Where(r => r.Id == id).FirstOrDefault();
                return View(model);
            
        }

        [HttpGet]
        public ActionResult AddRestaurant()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddRestaurant(Restaurant restaurant)
        {
            db = new RestaurantManagementDbContext();
            if (ModelState.IsValid)
            {
                db.Restaurants.Add(restaurant);
                db.SaveChanges();
                return RedirectToAction("Details", new { id = restaurant.Id });
            }
                return View();
            
        }

        
    }
}