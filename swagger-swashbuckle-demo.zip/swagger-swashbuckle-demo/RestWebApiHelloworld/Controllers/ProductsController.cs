﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestWebApiHelloworld.Models;

namespace RestWebApiHelloworld.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private static List<Product> products = new List<Product>
        {
            new Product{Id=1,Name="pen",Price=25},
            new Product{Id=2,Name="burger",Price=35},
            new Product{Id=3,Name="cake",Price=25}
        };
             
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(products);
        }

        [HttpGet("{id}")]
        public ActionResult<Product> Get(int id)
        {
            var product = products.Where(p => p.Id == id).FirstOrDefault();
            return Ok(product);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Product product)
        {
            products.Add(product);
            return Ok("Created");

        }
        [HttpPut("{id}")]
        
        public IActionResult Put(int id,[FromBody] Product product)
        {
            var prod = products.Where(p => p.Id == id).FirstOrDefault();
            prod.Name = product.Name;
            prod.Price = product.Price;
            return Ok("Updated");

        }

        
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var prod = products.Where(p => p.Id == id).FirstOrDefault();
            products.Remove(prod);
            return Ok("Deleted");

        }

    }
}